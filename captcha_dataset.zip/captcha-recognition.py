import os 
import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 

from pathlib import Path
from collections import Counter
from sklearn.model_selection import train_test_split

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
print("Tensorflow version: ", tf.__version__)


#Aynı kodun tekrar çalıştırıldığında aynı sonuçları vermesini sağlar.
seed = 1234
np.random.seed(seed)
tf.random.set_seed(seed)

#Path sınıfını kullanarak veri dizininin yolunu belirler.
data_dir = Path("C:\captcha-recognition-project\captcha_dataset\samples")


#png uzantılı tüm fotoğrafların listesini döndürür
images = list(data_dir.glob("*.png"))

#fotoğraf sayısını ekrana yazar.
print("Fotoğraf Sayısı:",len(images))

#görüntülerde yer alan tüm karakterlerin setini saklar.
characters = set()


#her captcha görüntüsünün uzunluğunu liste elemanı olarak saklar.
captcha_length = []

#fotoğraf - etiket bilgisini saklar.
dataset = []

for image_path in images:
     label = image_path.name.split(".png")[0] # "label" 'ı tutar. 
     captcha_length.append(len(label)) # captcha uzunluğunu tutar.
     dataset.append((str(image_path),label)) #  image-label bilgisini tutar. 
     
     for ch in label:
          characters.add(ch) # captcha karakterlerini characters'e ekler. 
     
#datasetten bir Pandas DataFrame oluşturur ve bu DataFrame'e belirli sütun adları verir.
dataset = pd.DataFrame(dataset,columns=["img_path","label"], index=None)

#verileri rastgele karıştırır,indekslerini sıfırlar.satırlar rastgele bir sırada ve indeksler 0'dan başlayarak sıralanmıştır.
dataset = dataset.sample(frac=1.).reset_index(drop=True)

print("Datasette benzersiz tüm karakterlerin sayısı: ", len(characters))
print("Maksimum captrcha uzunluğu: ", max(Counter(captcha_length).keys()))
print("Karakterlerin gösterimi: ", characters)
print("Datasetteki örnek sayısı: ", len(dataset))

#datasetin ilk 5 satırını yazdıralım
print(dataset.head())

#dataseti eğitim ve doğrulama kümesine ayıralım.
training_data ,validation_data = train_test_split(dataset,test_size=0.1,random_state = seed)

#eğitim ve doğrulama kümelerinin indekslerini sıfırlayalım.
training_data = training_data.reset_index(drop=True)
validation_data = validation_data.reset_index(drop=True)

print("Eğitim örneği sayısı: ", len(training_data))
print("Doğrulama örneği sayısı: ", len(validation_data))

#characters adlı bir diziyi kullanarak her bir karakteri benzersiz bir sayısal etikete eşleyen bir sözlük oluşturur.
char_to_labels = {char:idx for idx, char in enumerate(characters)}

#daha önce oluşturulan char_to_labels sözlüğünün tersini oluşturarak sayısal etiketleri karakterlere eşleyen bir sözlük (dictionary) oluşturur.
labels_to_char = {val:key for key, val in char_to_labels.items()}

#verilen bir CAPTCHA dizesinin geçerli olup olmadığını kontrol eder. 
def is_valid_captcha(captcha):
    for ch in captcha:
        if not ch in characters:
            return False
    return True


#Veri kümesinin fotoğraflarını ve etiketlerini array haline getirir. 
def generate_arrays(df,resize=True,img_height=50,img_width=200):
     #Veri çerçevesindeki toplam öğe sayısı.
     num_items = len(df)
     #Görüntü dizisini depolamak için boş bir numpy dizisi oluşturulur.
     images = np.zeros((num_items,img_height,img_width),dtype=np.float32)
     #Görüntü dizisini depolamak için boş bir numpy dizisi oluşturulur.
     labels = [0]*num_items
     
     for i in range(num_items):
          #Görüntü okunur
          img = cv2.imread(df["img_path"][i])
          #Görüntü gri tonlamalı hale dönüştürülür.
          img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
          #Görüntü yeniden boyutlandırılır (eğer resize bayrağı True ise).     
          if resize: 
            img = cv2.resize(img, (img_width, img_height))
          #Görüntü normalleştirilir (0 ile 1 arasında ölçeklenir).  
          img = (img/255.).astype(np.float32)
          #Etiket alınır.        
          label = df["label"][i]
          #Görüntü ve etiket, is_valid_captcha fonksiyonu ile kontrol edilir ve yalnızca geçerli CAPTCHA'lar eklenir.
          if is_valid_captcha(label):
               images[i, :, :] = img #geçerli captcha'nın görüntüsü diziye eklenir.
               labels[i] = label #geçerli captcha'nın etiketi diziye eklenir.
     return images, np.array(labels)

#training verileri fonksiyona verilir
training_data, training_labels = generate_arrays(df=training_data)
print("Number of training images: ", training_data.shape)
print("Number of training labels: ", training_labels.shape)

#validation verileri fonksiyona verilir
validation_data, validation_labels = generate_arrays(df=validation_data)
print("Number of validation images: ", validation_data.shape)
print("Number of validation labels: ", validation_labels.shape)

# Eğitim ve doğrulama için batch boyutu
batch_size = 16

# İstenilen görüntü boyutları
img_width = 200
img_height = 50

# Görüntülerin konvolüsyonel katmanlar tarafından aşağı örnekleneceği faktör
downsample_factor = 4

# Verideki herhangi bir CAPTCHA'nın maksimum uzunluğu
max_length = 5

# Eğitim verileri için bir veri üreteci nesnesi oluştur
train_data_generator = DataGenerator(data=training_data,
                                     labels=training_labels,
                                     char_map=char_to_labels,
                                     batch_size=batch_size,
                                     img_width=img_width,
                                     img_height=img_height,
                                     downsample_factor=downsample_factor,
                                     max_length=max_length,
                                     shuffle=True
                                    )

# Doğrulama verileri için bir veri üreteci nesnesi oluştur
valid_data_generator = DataGenerator(data=validation_data,
                                     labels=validation_labels,
                                     char_map=char_to_labels,
                                     batch_size=batch_size,
                                     img_width=img_width,
                                     img_height=img_height,
                                     downsample_factor=downsample_factor,
                                     max_length=max_length,
                                     shuffle=False
                                    )
